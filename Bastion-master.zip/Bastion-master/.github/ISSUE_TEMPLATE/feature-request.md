---
name: Feature Request
about: Suggest an idea for Bastion
title: "[IDEA]: "
labels: Feature Request
assignees: ''

---

<!-- A clear and concise description of the idea you'd like to suggest. -->
