<!--
    Thank you for opening an issue.


    This issue tracker is for bugs and issues found within this repository, and
    for feature requests/suggestions for this repository.
    If you require general support or if you have some question, please ask in
    the Bastion HQ: https://discord.gg/fzx8fkt

    If you're reporting a bug or suggesting a feature, choose the right template
    by going here - https://github.com/TheBastionBot/Bastion/issues/new/choose -
    so that it makes it easy for you to write the report and easy for us to
    understand and resolve it.


    If it's not an bug report or feature request/suggestion, enter your issue
    details, in as much details as possible, after the end of this section.
-->
