/**
 * @file isPublicBastion
 * @author Sankarsan Kampa (a.k.a k3rn31p4nic)
 * @license GPL-3.0
 */

module.exports = Client => {
  if (Client.user.id === '267035345537728512') return true;
  return false;
};
